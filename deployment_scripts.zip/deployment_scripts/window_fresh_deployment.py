"""
# Copyright (c) 2020-present General Electric Company. All rights
# reserved.
# 
# The copyright to the computer
# software herein is the property of General Electric Company. The
# software may be used and/or copied only with the written permission of
# General Electric Company or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# software has been supplied.
#
"""

import json
import os
import shlex
import subprocess
import time
import zipfile
import shutil
 
status_file_path = '.\\status.txt'


def sectionbreak():
    print(
        '\n.................................................................................................................\n')


def execute_command(command):
    output = []
    cmd_string = '"cmd /c ' + command +'"'
    print("executing " + cmd_string)
    try:
        os.system(cmd_string)
    except:
        print("an exception occurred")
    return output


def execute_command_sync(command, working_directory):
    try:
        os.chdir(working_directory)
        process = subprocess.Popen('"cmd /c ' + command, shell=True,
                                cwd=working_directory,
                                stdout=subprocess.PIPE)
        process.wait(30)
    except Exception as ex:
        print(str(ex))


def get_service_status(service_name):
    print('Checking status of ' + service_name + '...')
    service_status_query = 'sc query ' + service_name + ' | find "STATE"' 
    cmd_string = 'cmd /c ' + service_status_query 

    status = os.popen(cmd_string)
    status_lst = status.read()
    
    if len(status_lst) == 0:
        print('Status:  Non-Existent')
        return 'non-existent'

    status_lst = status_lst.split()
    service_status = status_lst[3]
    print("Status:  " + service_status)
    return service_status.lower()   


def install(service_name, service_exe_path, service_exe_name, build_type):
    if 'dotnet' == build_type.lower():
        service_exe = service_exe_path + '\InstallService.bat'
        output = execute_command(service_exe)
        return output
    elif ('gradle' == build_type.lower()) or ('node' == build_type.lower()) or ('python' == build_type.lower()):        
        if 'python' == build_type.lower():
            print(os.getcwd() + "/" + service_exe_path)
            execute_command_sync(r'python -m venv venv', working_directory=os.getcwd() + "/" + service_exe_path)
            execute_command_sync(r'venv\\Scripts\\activate', working_directory=os.getcwd() + "/" + service_exe_path)
            execute_command_sync(r'venv\\Scripts\\pip install lib\\wheel-0.34.2-py2.py3-none-any.whl',
                                 working_directory=os.getcwd() + "/" + service_exe_path)
            execute_command_sync(r'venv\\Scripts\\pip install --no-index -r requirements.txt --find-link=lib --no-build-isolation',
                                 working_directory=os.getcwd() + "/" + service_exe_path)
            execute_command_sync(r'venv\\Scripts\\deactivate', working_directory=os.getcwd() + "/" + service_exe_path)          
            time.sleep(30)

        service_exe = service_exe_path + '\\' + service_exe_name
        cmd_string = service_exe + ' install'
        output = execute_command(cmd_string)       
        return output


def uninstall_and_install(service_name, service_exe_path, service_exe_name, build_type):
    cmd_string = 'sc delete ' + service_name
    output = execute_command(cmd_string) 
    time.sleep(5)
    output = install(service_name, service_exe_path, service_exe_name, build_type)
    return output

def stop_uninstall_and_install(service_name, service_exe_path, service_exe_name, build_type):
    cmd_string = 'sc stop ' + service_name
    output = execute_command(cmd_string)
    output = uninstall_and_install(service_name, service_exe_path, service_exe_name, build_type)
    return output

def start_service(service_name):
    print('service name: ' + service_name)
    cmd_servicestart = 'sc start ' + service_name
    output = execute_command(cmd_servicestart)
    return output        

def execute_command_live(command):
    process = subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE)
    while True:
        output = process.stdout.readline()
        if output == '' and process.poll() is not None:
            break
        if output:
            print(output.strip())
    rc = process.poll()
    return rc


def linux_to_windows_path(path):
    return path.replace('/', '\\')


def unzip(zip, target):
    print('unzipping ' + zip + ' into  ' + target)
    with zipfile.ZipFile(zip, 'r') as zip_ref:
        zip_ref.extractall(target)


def merge_build(hmi_src_path, hmi_dst_path):
    copy_command = 'cmd /c xcopy ' + hmi_src_path + '\\* ' + hmi_dst_path + ' /y /f /j /s /z'
    os.system(copy_command)
    time.sleep(5)
    index_move_command = 'cmd /c move ' + hmi_dst_path + '\\index.html ' + hmi_dst_path + '\\..'
    os.system(index_move_command)

# this method deletes the directory if it exists.
def delete_dir(foldername):
    if os.path.isdir(foldername):
        try:
            shutil.rmtree(foldername)
        except OSError as e:
            print("Error: %s : %s" % (foldername, e.strerror))
        else:
            print("Deleted: " + foldername)

def getServiceStatus(servicename):    
    service = None
    try:
        service = psutil.win_service_get(servicename)
        service = service.as_dict()
    except Exception as ex:
        print(str(ex))
    return service

# MAIN SECTION

with open('config.json', 'r') as config_file:
    configuration = json.load(config_file)

ngs_dir = linux_to_windows_path(configuration['deployment_dir'])

print('Stopping all the services...')
for comps in configuration['components']:
    service_name = comps['service_name']
    status = get_service_status(service_name)
    if 'running' == status:
       cmd_string = 'sc stop ' + service_name
       output = execute_command(cmd_string)
       print(output)

for comps in configuration['components']:
    service_name = comps['name']
    sectionbreak()
    print('Deploying component: ' + service_name)
    version = comps['last_deployed_version']
    zip_name = service_name + '.' + version + '.zip'
    zip = '..\\' + zip_name
    comp_dir = ngs_dir + comps['folder_name']
    #output = execute_command('rmdir /f /S /Q ' + comp_dir)
    delete_dir(comp_dir)
    unzip(linux_to_windows_path(zip), linux_to_windows_path(comp_dir))
    
    if service_name == 'ren-ngs-webserver-svc':
        hmi_dst_path = comp_dir + '\\' + comps['hmi_dst_path']
        output = execute_command('mkdir ' + linux_to_windows_path(hmi_dst_path))
        keycloak_json_path = 'C:\\ngs\\systemconfig\\keycloak.json'
        keycloak_json_copy_command = 'cmd /c xcopy ' + keycloak_json_path + ' ' + linux_to_windows_path(
            hmi_dst_path) + '\\.. /y /f /j /s /z'
        os.system(keycloak_json_copy_command)
        print('keycloak.json copied')
    if service_name == 'ren-ngs-web-hmi':
        hmi_src_path = comp_dir + '\\' + comps['hmi_src_path']
        merge_build(linux_to_windows_path(hmi_src_path), linux_to_windows_path(hmi_dst_path))
        print('hmi_src_path copied')

delete_dir(ngs_dir + 'scripts')
output = execute_command('mkdir ' + ngs_dir + 'scripts')
cmd_string = 'cmd /c xcopy .\\config.json ' + ngs_dir + 'scripts /y /f /j /s /z'
os.system(cmd_string)
cmd_string = 'cmd /c xcopy .\\window_deployment.py ' + ngs_dir + 'scripts /y /f /j /s /z'
os.system(cmd_string)

final_deploy_command = 'python window_deployment.py'
os.chdir(ngs_dir + 'scripts')

for comps in configuration['components']:    
    service_name = comps['service_name']
    sectionbreak()
    print('Installing component: ' + service_name)
    dir_name = comps['folder_name']
    service_exe_name = service_name + '.exe'
    service_exe_path = '..\\' + dir_name
    if service_name == 'ren-ngs-web-hmi':
        continue

    print('service name: ' + service_name)
    status = get_service_status(service_name)     

    if 'running' == status:
        output = stop_uninstall_and_install(service_name, service_exe_path, service_exe_name, comps['build_type'])
    elif 'stopped' == status:
        output = uninstall_and_install(service_name, service_exe_path, service_exe_name, comps['build_type'])
    elif 'non-existent' == status:
        output = install(service_name, service_exe_path, service_exe_name, comps['build_type'])
    else:
        print('Unrecognized service status.. \nThe script ended prematurely. You should follow manual deployment\n')
        exit()

print('Starting all the services...')
for comps in configuration['components']:
    service_name = comps['service_name']
    output = start_service(service_name)   
    print(output)

final_deploy_command = 'python window_deployment.py'
os.system(final_deploy_command)
os.system("tskill cmd")
