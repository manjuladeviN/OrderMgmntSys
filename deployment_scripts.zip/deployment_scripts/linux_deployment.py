"""
# Copyright (c) 2020-present General Electric Company. All rights
# reserved.
# 
# The copyright to the computer
# software herein is the property of General Electric Company. The
# software may be used and/or copied only with the written permission of
# General Electric Company or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# software has been supplied.
#
"""

import os
import json
import io
import shutil
import time
import errno


def copy(src, dest):
    try:
        shutil.copytree(src, dest)
    except OSError as e:
        # If the error was caused because the source wasn't a directory
        if e.errno == errno.ENOTDIR:
            shutil.copy(src, dest)
        else:
            print('Directory not copied. Error: %s' % e)


def execute_command(command):
    output = os.popen(command).read()
    print(output)
    return output


def get_service_status(service_name='ren-ngs-configuration-svc'):
    message = execute_command('systemctl status ' + service_name)
    if '' == message:
        return 'non-existent'
    output = message.split()
    count = 0
    for word in output:
        if 'Active:' == word:
            break
        else:
            count += 1
    status = output[count + 1]
    print("\n\nstatus of " + service_name + ': ' + status)
    return status


def start_service(service_name):
    while get_service_status(service_name).lower() != 'active':
        output = execute_command('systemctl start ' + service_name)
        print(output)
        print("Service status for: " + service_name + "is :" + get_service_status(service_name))
        print("Started Service: " + service_name)


# MAIN SECTION

with open('config.json', 'r') as config_file:
    configuration = json.load(config_file)

dir_path = os.popen('cd .. && pwd').read().strip()
output = execute_command('chmod -R 0777 ' + dir_path)
print(output)

# Stopping services
for comps in configuration['components']:
    service_name = comps['service_name']
    folder_name = comps['folder_name']
    stop_command = 'systemctl stop ' + service_name
    execute_command(stop_command)

# Service loading
for comps in configuration['components']:
    service_name = comps['name']
    if 'ren-ngs-web-hmi' == service_name.lower():
        continue
    start_service(comps['service_name'])
    if 'ren-ngs-configuration-svc' == service_name:
        time.sleep(60)
    else:
        time.sleep(2)
