#!/bin/bash
echo "Put Things to CD_* directory first"
sudo chmod 0777 -R *
for dir in ./*; do (cd $dir && sudo cp ren-ngs*.service /etc/systemd/system); done
cd ren-ngs-webserver*
sudo cp build/level_1/level_2/ren-ngs-webserver-svc.service /etc/systemd/system
cd ..
cd /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl stop ren-ngs*.service
sudo systemctl start ren-ngs-configuration-svc.service

sleep 25
CONFIG_SVC_STATUS="$(curl -s -I http://localhost:7070/swagger-ui.html | grep HTTP/ | awk {'print $2'})"
if [ $CONFIG_SVC_STATUS == 200 ]
then
        sudo systemctl start ren-ngs-sdirealtime-adpt.service
        sudo systemctl start ren-ngs-sdialarms-adpt.service
        sudo systemctl start ren-ngs-mqtttoredis-svc.service
        sudo systemctl start ren-ngs-ruleengine-svc.service
        sudo systemctl start ren-ngs-realtime-appsvr.service
        sudo systemctl start ren-ngs-alarms-appsvr.service
        sudo systemctl start ren-ngs-commands-appsvr.service
        sudo systemctl start ren-ngs-webserver-svc.service
        echo "All Services Started properly"
else
        echo "Configuration Service Did not Start Properly, please check the properties"
fi

