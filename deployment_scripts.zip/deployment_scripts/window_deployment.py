"""
# Copyright (c) 2020-present General Electric Company. All rights
# reserved.
# 
# The copyright to the computer
# software herein is the property of General Electric Company. The
# software may be used and/or copied only with the written permission of
# General Electric Company or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# software has been supplied.
#
"""

import os
import time
import json

status_file_path    =   '.\\status.txt'    

def sectionbreak():
    print('\n.................................................................................................................\n')


def execute_command(command):
    output  =   []
    cmd_string  =   'runas /savecred /env /user:Administrator "cmd /c ' +   command +   " > "   +   status_file_path    +   '"'
    print("executing " + cmd_string)
    os.popen(cmd_string).read()
    time.sleep(1)
    with open("status.txt","r") as fileR:
        for line in fileR:
            line    =   line.strip()
            output.append(line)            
    fileR.close()   
    return output
    

    
def get_service_status(service_name):
    print('Checking status of ' +   service_name    +   '...')    
    service_status_query    =   'sc query ' +   service_name    +   ' | find \\"STATE\\"'
    status_lst  =   execute_command(service_status_query)
    if len(status_lst)   ==  0:
        print('Status:  Non-Existent')
        return 'non-existent'
    status_lst  =   status_lst[0].split()
    service_status  =   status_lst[-1]
    print("Status:  "   +   service_status)
    return service_status.lower()


def start_service(service_name):
    cmd_string  =   'sc start '  +   service_name
    output  =   execute_command(cmd_string)    
    return output
    
#MAIN SECTION

with open('config.json', 'r') as config_file:
    configuration   =   json.load(config_file)
    
#Stop all services

print('Stopping all the services...')
cmd_string  =   'wmic service where \\"name like \'ren-ngs%%\'\\" call stopservice'
output  =   execute_command(cmd_string)
time.sleep(15)


#Start all services

for comps in configuration['components']:    
    service_name    =   comps['name']
    sectionbreak()
    print('Deploying component: '   +   service_name)
    if  service_name   ==  'ren-ngs-web-hmi':
        continue
    while 'running'    !=  get_service_status(service_name):
        start_service(service_name)
        time.sleep(0.5)
    if 'ren-ngs-configuration-svc'  ==  service_name:
        time.sleep(60)
    else:
        time.sleep(2)
exit()
