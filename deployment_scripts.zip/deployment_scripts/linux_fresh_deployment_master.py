"""
# Copyright (c) 2020-present General Electric Company. All rights
# reserved.
#
# The copyright to the computer
# software herein is the property of General Electric Company. The
# software may be used and/or copied only with the written permission of
# General Electric Company or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# software has been supplied.
#
"""

import errno
import json
import os
import shlex
import shutil
import subprocess



def execute_command_live(command):
    process = subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE)
    while True:
        output = process.stdout.readline()
        if output == '' and process.poll() is not None:
            break
        if output:
            print(output.strip())
    rc = process.poll()
    return rc


def execute_command(command):
    output = os.popen(command).read()
    print(output)
    return output


def execute_command_sync(command):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    process.wait()


def get_service_status(service_name='ren-ngs-configuration-svc'):
    message = execute_command('systemctl status ' + service_name)
    if '' == message:
        return 'non-existent'
    output = message.split()
    count = 0
    for word in output:
        if 'Active:' == word:
            break
        else:
            count += 1
    status = output[count + 1] if len(output) > count else "Not found"
    print("\n\nstatus of " + service_name + ': ' + status)
    return status


def stop_service(service_name):
    # Fumction to stop the given service
    output = execute_command('systemctl stop ' + service_name)
    print(output)
    print("Stopped service: " + service_name)
    return output


def load_service(service_name, src):
    dst = "/etc/systemd/system/"
    dst_filename = dst + '/' + service_name + '.service'
    copy(src, dst_filename)
    output = execute_command('chmod 0777 ' + dst_filename)
    print(output)
    output = execute_command('systemctl daemon-reload')
    print(output)
    output = execute_command('systemctl enable ' + service_name)
    print(output)
    print("Loaded service: " + service_name)


def copy(src, dest):
    try:
        shutil.copytree(src, dest)
    except OSError as e:
        # If the error was caused because the source wasn't a directory
        if e.errno == errno.ENOTDIR:
            shutil.copy(src, dest)
        else:
            print('Directory not copied. Error: %s' % e)


def merge_build(hmi_src_path, hmi_dst_path):
    copy_command = 'cp -r ' + hmi_src_path + '/* ' + hmi_dst_path
    execute_command(copy_command)
    index_move_command = 'mv ' + hmi_dst_path + '/index.html ' + hmi_dst_path + '/..'
    execute_command(index_move_command)


with open('config.json', 'r') as config_file:
    configuration = json.load(config_file)

ngs_dir = configuration['deployment_dir']
hmi_dst_path = ''

execute_command('mkdir -p ' + ngs_dir)

# Stopping services and cleanup old directory
for comps in configuration['components']:
    service_name = comps['service_name']
    status = get_service_status(service_name)
    if ('active' == status.lower()) or ('activating' == status.lower()):
        folder_name = comps['folder_name']
        stop_command = 'systemctl stop ' + service_name
        execute_command(stop_command)
        execute_command('rm -rf ' + ngs_dir + folder_name)

# Remove old scripts directory
execute_command('rm -rf ' + ngs_dir + 'scripts')

for comps in configuration['components']:
    comp_dir = ngs_dir + comps['folder_name']
    comp_user = configuration['user']
    execute_command('mkdir ' + comp_dir)
    artifact_name = comps['name'] + '.' + comps['last_deployed_version_master'] + '.tar.gz'
    os.system('tar -C ' + comp_dir + ' -xvf ../' + artifact_name)

    if comps['name'] == 'ren-ngs-webserver-svc':
        hmi_dst_path = comp_dir + '/' + comps['hmi_dst_path']
        execute_command('mkdir  ' + hmi_dst_path)
        keycloak_json_copy_command = 'cp ' + '/usr/local/keycloak.json ' + hmi_dst_path + '/..'
        execute_command(keycloak_json_copy_command)
    if comps['name'] == 'ren-ngs-web-hmi':
        hmi_src_path = comp_dir + '/' + comps['hmi_src_path']
        merge_build(hmi_src_path, hmi_dst_path)
        continue
    comp_service_file = comp_dir + '/' + comps['service_name'] + '.service'
    execute_command('sed -i s+\$WORKSPACE+' + comp_dir + '+g ' + comp_service_file)
    execute_command('sed -i s+\$USER+' + comp_user + '+g ' + comp_service_file)

    if comps['build_type'] == 'node':   
        node_full_path = '/usr/share/node-v12.16.1/bin/node'    
        execute_command('sed -i s+\$NODE_COMMAND+' + node_full_path + '+g ' + comp_service_file)
        #execute_command('sed -i s+\$NODE_COMMAND+' + configuration['node_cmd'] + '+g ' + comp_service_file)
    if comps['build_type'] == 'python':
        execute_command_sync('cd ' + comp_dir + ' && ' + configuration['python_cmd'] + ' -m venv venv')
        execute_command_sync('sudo chmod 0777 ' + comp_dir + '/venv -R')
        venv_cmd = 'source ' + comp_dir + '/venv/bin/activate && ' + configuration[
            'pip_cmd'] + ' install ' + comp_dir + '/lib/wheel-0.34.2-py2.py3-none-any.whl && ' + configuration[
                       'pip_cmd'] + ' install --no-index -r ' + comp_dir + '/requirements.txt --find-link=' + comp_dir + '/lib' + ' && ' + comp_dir + '/venv/bin/deactivate'
        execute_command_sync(venv_cmd)
        
execute_command('mkdir ' + ngs_dir + 'scripts')
copy('./config.json', ngs_dir + 'scripts')
copy('./linux_deployment.py', ngs_dir + 'scripts')

os.chdir(ngs_dir + 'scripts')

# Service loading
for comps in configuration['components']:
    service_name = comps['service_name']
    service_file_path = '../' + comps['folder_name'] + '/' + comps['service_name']
    if ('ren-ngs-web-hmi' == service_name) or ('ren-ngs-historicalhttpdata-adpt' == service_name):
        continue
    version = comps['last_deployed_version']
    status = get_service_status(service_name)
    if ('active' == status.lower()) or ('activating' == status.lower()):
        stop_service(service_name)
        load_service(service_name, service_file_path + '.service')
    elif ('inactive' == status.lower()) or ('non-existent' == status.lower()) or ('failed' == status.lower()):
        load_service(service_name, service_file_path + '.service')
    else:
        print("Invalid service status! Kindly follow maunal deployment")
        break

final_deploy_command = 'sudo python linux_deployment.py'
os.system(final_deploy_command)
